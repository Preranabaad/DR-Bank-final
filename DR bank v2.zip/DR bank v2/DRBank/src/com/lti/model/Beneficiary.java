package com.lti.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

	@Component
	@Entity
	@Table(name="DR_BENEFICIARY")
	@SequenceGenerator(name="dr_beneficiary_seq" , sequenceName="DR_BENEFICIARYID_SEQ")
	public class Beneficiary {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="dr_beneficiary_seq")
	private long beneficiary_Id;
	private String  beneficiary_IFSC;
	private long  beneficiary_Acc_No;
	private String beneficiary_name;
	private String  Nick_Name;
	private double  amount;
	private long customer_Id;


	public Beneficiary(){
		
	}


	public Beneficiary(long beneficiary_Id, String beneficiary_IFSC, long beneficiary_Acc_No, String beneficiary_name,
			String nickName, double amount, long customer_Id) {
		super();
		this.beneficiary_Id = beneficiary_Id;
		this.beneficiary_IFSC = beneficiary_IFSC;
		this.beneficiary_Acc_No = beneficiary_Acc_No;
		this.beneficiary_name = beneficiary_name;
		this.Nick_Name = nickName;
		this.amount = amount;
		this.customer_Id = customer_Id;
	}


	public long getBeneficiary_Id() {
		return beneficiary_Id;
	}


	public void setBeneficiary_Id(long beneficiary_Id) {
		this.beneficiary_Id = beneficiary_Id;
	}


	public String getBeneficiary_IFSC() {
		return beneficiary_IFSC;
	}


	public void setBeneficiary_IFSC(String beneficiary_IFSC) {
		this.beneficiary_IFSC = beneficiary_IFSC;
	}


	public long getBeneficiary_Acc_No() {
		return beneficiary_Acc_No;
	}


	public void setBeneficiary_Acc_No(long beneficiary_Acc_No) {
		this.beneficiary_Acc_No = beneficiary_Acc_No;
	}


	public String getBeneficiary_name() {
		return beneficiary_name;
	}


	public void setBeneficiary_name(String beneficiary_name) {
		this.beneficiary_name = beneficiary_name;
	}


	public String getNick_Name() {
		return Nick_Name;
	}


	public void setNick_Name(String nickName) {
		Nick_Name = nickName;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	public long getCustomer_Id() {
		return customer_Id;
	}


	public void setCustomer_Id(long customer_Id) {
		this.customer_Id = customer_Id;
	}

	}






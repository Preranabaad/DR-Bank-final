package com.lti.dao;

import com.lti.model.Drtransactions;

public interface TransactionDao {

	public boolean validatepin(int tpin, String username);

	public Drtransactions performtransaction(double amount, long accno, long benaccno,String remark, String type);

	
	

}

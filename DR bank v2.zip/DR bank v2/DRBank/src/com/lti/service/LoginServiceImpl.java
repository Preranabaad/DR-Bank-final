package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.LoginDao;
import com.lti.model.Banker_Info;
import com.lti.model.Internet_banking;
@Service
public class LoginServiceImpl implements LoginService {
	@Autowired
	private LoginDao dao;
	
	//Login
	@Override
	public boolean readUserLogin(String username, String password) {
		List<Internet_banking> userlist=dao.UserLogin(username, password);
		for(Internet_banking i: userlist)
		{
			if(i.getLock_status()==0)
			{
				return true;
			}
		}
		return false;
	}
	
	@Override
	//public void CreateUserIb(String username,double accno, String password, int pin) {
		// TODO Auto-generated method stub
		
	//}
	
	
	//Admin
	public boolean readAdminLogin(String email, String password) {
		int result=dao.AdminLogin(email, password);
			if(result==0)
			{
				return false;
			}
	
		return true;
	}
	
	//Change Password
	@Transactional
	@Override
	public int setPassword(String password, String username) {
		return dao.setUserPassword(password,username);
		
		
	}
	
	//Forgot Password
	@Override
	public Internet_banking getusername(long accno) {
		// TODO Auto-generated method stub
		return dao.getusername(accno);
	}
	@Override
	public String getemail(long customer_id) {
		// TODO Auto-generated method stub
		return dao.getemail(customer_id);
	}
	
	// Lock After 3times
	@Transactional
	@Override
	public long lock(String username) {
		 return dao.setLockStatus(username);
		
	}
	

}

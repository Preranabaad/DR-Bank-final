package com.lti.service;

import com.lti.model.Internet_banking;

public interface LoginService {
//login
public boolean readUserLogin(String username,String password);

//Register for Internet BAnking
//public void CreateUserIb(String username,double accno,String password,int pin);

//Admin Login
public boolean readAdminLogin(String email,String password);

//Lock After 3times
public long lock(String username);

//Change Password
public int setPassword(String password, String username);

//Forgot Password
public Internet_banking getusername(long accno);
public String getemail(long customer_id);
}

package com.lti.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.lti.model.Internet_banking;
import com.lti.service.LoginService;

@Controller

public class LoginController {
	@Autowired
	private LoginService service;
	@Autowired
	private MailSender mailSender;
	@Autowired
	private SimpleMailMessage message;
	@Autowired
	private Internet_banking ib;

	private static int attempts=0;
	
	//Home Page
	@RequestMapping(path = "/")
	public String UserloginPage() {
		return "Home";
	}
	//Home Page
	@RequestMapping(path = "Home")
	public String home() {
		return "Home";
	}
	
	//Login
	@RequestMapping(path = "loginpage")
	public String LoginPage()
	{
		return "Login";
	}
	@RequestMapping(path = "login.do", method = RequestMethod.POST)
	public String Userlogin(@RequestParam("username") String username, @RequestParam("password") String password,HttpServletRequest request, HttpSession session) {
		boolean result = false;
		if(attempts<3)
		{
		result = service.readUserLogin(username, password);
		}
		if (result) {
			attempts=0;
			request.getSession(true);
			session.setAttribute("username", username);
			return "UserdashBoard";
		}
		else if(attempts>=3)
		{
			long id= service.lock(username);
			String email=service.getemail(id);
			message.setTo(email); //set a proper recipient of the mail
			
			message.setSubject("Account Locked");
			message.setText("There were too many unsucessfull attempts. Hence for security purpose we have locked your internet banking. To activate your internet banking please to go our website and change your password");
			mailSender.send(message);
			attempts=0;
			return "redirect:loginpage";
		}
		else
		{
			attempts++;
			return "redirect:loginpage";
		}

	}

	//Register For Internet Banking
	@RequestMapping(path="registeruser")
	public String RegisterIBPage()
	{
		return "RegisterForIB";
	}
	
	//Admin Login
	@RequestMapping(path = "AdminLoginPage")
	public String AdminloginPage() {
		return "AdminLogin";
	}

	@RequestMapping(path="Adminlogin", method = RequestMethod.POST)
	public String AdminLogin(@RequestParam("email") String email, @RequestParam("password") String password){
		boolean result= service.readAdminLogin(email,password);
		if (result) {
			return "AdminDashBoard";
		}
		return "redirect:AdminLoginPage";
	}
	
	//LogOut
	  @RequestMapping(value="logout",method = RequestMethod.GET)
      public String logout(HttpServletRequest request){
		 
          HttpSession httpSession = request.getSession();
          httpSession.invalidate();
          return "redirect:/";
      }
	  
	  //Navigation
	  @RequestMapping(path="homepage")
	  public String homePage(){
		 
		return "UserdashBoard";
		  
	  } 
	  @RequestMapping(value="back")
      public String Back(){       
          return "AdminDashBoard";
        	  }
	  
	  @RequestMapping(path="home")
    	  public String HomePage(){
    		  return "Home";
          }
	  
  
	//forgot password
	  @RequestMapping(path="forgotPassword")
	  public String forgotPassword(){
		  return "enterAccNo";
		
	  }
	  
	  @RequestMapping(path="forgotpassword.do",method = RequestMethod.POST)
	  public String forgotpasswordOTP(@RequestParam("account_number") long accno,HttpSession session){
		  	int otp   =(int) (Math.random()*9000)+1000;  
		    
		  	ib= service.getusername(accno);
		  	
		   String username= ib.getUsername();
		   String email=service.getemail(ib.getCustomer_id());
			
			message.setTo(email); //set a proper recipient of the mail
			
			message.setSubject("Your One Time Password");
			message.setText("Your Username is: "+username+" OTP:"+otp);
			mailSender.send(message);
			session.setAttribute("otp", otp);
			
		  return "PasswordOTP";
	  }
	  
	  //Change Password
	  @RequestMapping(path="ChangePasswordPage")
	  public String ChangePasswordPage(@RequestParam("username") String username, HttpSession session,HttpServletRequest request){
		  request.getSession(true);
		  session.setAttribute("uname", username);
		  return "ChangePassword";
	  }
	  
	  @RequestMapping(path="ChangePassword")
	  public String ChangePassword(@RequestParam("set_password") String Password,HttpSession session){
		  String username=(String) session.getAttribute("uname");
		  int result=service.setPassword(Password,username);
		  return "redirect:loginpage";
	  }
	  
	  //ERROR page Navigation
	  @RequestMapping(path="Wrong")
	  public String Wrong(){
		  return "Wrong";
	  }
}
